# MedTrack Multi-Branch Hospital Operations Report
**Generated on:** 2026-11-08 16:03:02

## 1. Executive Summary
- **Active Hospital Branches:** 3 (Branch A - Metro Central, Branch B - Tech City, Branch C - Green Valley)
- **Total Scheduled Appointments:** 10
- **Successfully Completed:** 5 (50.0%)
- **Emergency Cancellations & Auto-Reschedules:** 1
- **No-Show Patient Rate:** 1
- **Total Consultation Revenue:** ₹3,950.00

## 2. Branch Performance Breakdown
| Branch Code | Total Appts | Completed | Emergencies | No-Shows | Revenue (₹) |
|---|---|---|---|---|---|
| BRANCH-A | 4 | 2 | 1 | 0 | ₹1,400.00 |
| BRANCH-B | 3 | 1 | 0 | 1 | ₹750.00 |
| BRANCH-C | 3 | 2 | 0 | 0 | ₹1,800.00 |

## 3. Pharmacy Stock Replenishment Alerts
| Branch | Medicine Name | In Stock | Reorder Level | Status |
|---|---|---|---|---|
| BRANCH-A | Amoxicillin 625 | 15 | 30 | ⚠️ LOW STOCK |
| BRANCH-C | Telmisartan 40 | 8 | 35 | ⚠️ LOW STOCK |
