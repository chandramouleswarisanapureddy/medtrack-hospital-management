# MEDTRACK – REAL-TIME MULTI-BRANCH HOSPITAL MANAGEMENT SYSTEM

A comprehensive B.Tech Computer Science (Data Science) academic project integrating **Relational Database Management Systems (DBMS)**, **Full-Stack Web Engineering**, **Machine Learning**, **Data Engineering**, and **Operating System Concurrency Concepts**.

---

## 🏥 Project Overview

MedTrack is a centralized hospital management website engineered to unify operations across three distinct hospital branches:
1. **Branch A:** MedTrack Metro Central (Primary Tertiary Hospital)
2. **Branch B:** MedTrack Tech City (Surgical & Specialty Clinic)
3. **Branch C:** MedTrack Green Valley (Neurology & Rehabilitation Center)

The system enables the **Head of Hospital (Super Admin)** to oversee all branches, **Branch Heads** to manage their isolated branch, **Doctors** to view clinical queues and write prescriptions, **Receptionists** to handle patient intakes, and **Patients** to book appointments and receive urgent emergency rescheduling alerts.

---

## 🌟 Key Features & Academic Disciplines

### 1. Database Architecture (DBMS - 3NF Normalized)
- Fully normalized PostgreSQL schema in **Third Normal Form (3NF)** eliminating insertion, deletion, and update anomalies.
- **Concurrency Safety:** Partial unique index preventing double-booking of doctor slots at the database storage engine level:
  ```sql
  CREATE UNIQUE INDEX idx_unique_active_doctor_slot 
  ON appointments(doctor_id, appointment_date, appointment_time)
  WHERE status NOT IN ('Cancelled', 'No-show', 'Cancelled - Emergency');
  ```
- **Inventory Safety:** Non-negative check constraint `CHECK (quantity_available >= 0)` and transaction-safe pessimistic row locking `SELECT ... FOR UPDATE` preventing negative pharmaceutical stock.
- **Security:** Granular Supabase **Row Level Security (RLS)** enforcing multi-branch isolation.

### 2. Special Emergency Cancellation & Auto-Rescheduling Engine
- When an administrator reports an emergency (e.g. sudden doctor absence, facility outage), stored procedure `declare_hospital_emergency()` executes:
  1. Identifies all affected confirmed appointments.
  2. Marks original appointments as `Cancelled - Emergency` with immutable audit history.
  3. Automatically searches the earliest available replacement slot within 7 days (Priority 1: Same Doctor; Priority 2: Alternative Doctor in same department and branch).
  4. Links the replacement appointment to the original via relational foreign keys.
  5. Places unfillable requests in a dedicated manual resolution queue.
  6. Automatically sends In-App reschedule notifications displaying old vs new date, doctor, branch, and token.

### 3. Integrated Web Portal (No Mandatory Login Friction)
- Public homepage (`index.html`) opens directly without forcing a login screen.
- Public visitors can inspect hospital facilities, branch directories, and book appointments.
- Integrated **Academic Role Switcher** in the top navigation bar allowing examiners to switch between **Super Admin**, **Branch Head**, **Doctor**, **Receptionist**, and **Patient** with a single click.

### 4. Machine Learning Module (Kaggle Dataset)
- Dataset: Kaggle *Medical Appointment No Shows* (110,527 clinical visits).
- Predicts patient no-show risk based on Age, Gender, Scholarship, Hypertension, Diabetes, Alcoholism, Handicap, SMS reminder, Booking Lead Days, and Day-of-Week.
- Evaluates and compares **Logistic Regression** and **Random Forest Classifier** on Accuracy, Precision, Recall, F1-Score, and ROC-AUC.
- Serialized pipeline bundle saved with `joblib` into `ml/models/noshow_model.joblib`.
- Standalone inference script `ml/predict.py` and interactive risk badge in the appointment portal.

### 5. Data Engineering ETL Pipeline
- `data_engineering/pipeline.py` implements an Extract, Transform, Validate, and Load (ETL) pipeline.
- Ingests operational visit logs and pharmacy records, validates non-negative stock constraints, and exports clean dimensional data marts (`fact_appointments.csv`, `dim_branch_performance.csv`).
- `data_engineering/generate_reports.py` produces automated JSON executive summaries and Markdown reports.

### 6. Operating System Concurrency Demonstration
- `os_demo/concurrent_booking.py` simulates two concurrent patient threads attempting to reserve the exact same doctor and time slot simultaneously.
- Demonstrates:
  - **Test 1 (Unsynchronized):** Race condition manifests; thread context switch inside critical section causes a double-booking bug.
  - **Test 2 (Synchronized with Mutex):** `threading.Lock` enforces mutual exclusion; exactly one patient books the slot while the other is safely rejected.
  - Academic comparison bridging in-memory OS Mutex with distributed database ACID transactions.

---

## 📁 Project Directory Structure

```text
MedTrack/
│
├── index.html                     # Public Hospital Network Homepage (Opens Directly)
├── dashboard.html                 # Role-Aware Clinical Operations Dashboard
├── appointments.html              # Concurrency-Safe Booking Wizard & Registry
├── emergency.html                 # Emergency Operations & Auto-Rescheduling Center
├── patients.html                  # Patient Demographic Directory & Medical History
├── doctors.html                   # Doctor Faculty, Qualifications & Rosters
├── pharmacy.html                  # Pharmaceutical Inventory & Sales Dispensing
├── reports.html                   # Multi-Branch Analytics & ML Evaluation
│
├── css/
│   ├── style.css                  # Core clinical styling, design tokens & modals
│   ├── dashboard.css              # Sidebar, topbar, KPI cards & notification drawer
│   └── responsive.css             # Mobile & tablet responsive adaptations
│
├── js/
│   ├── config.js                  # Supabase credentials & offline synthetic demo store
│   ├── supabase.js                # Supabase client adapter & realtime pub/sub
│   ├── auth.js                    # Session management & academic role switcher
│   ├── navigation.js              # Shared topbar, sidebar & notification counter
│   ├── dashboard.js               # KPI metrics calculation & recent queues
│   ├── appointments.js            # Booking wizard & AI no-show risk estimation
│   ├── emergency.js               # Emergency reporting & auto-rescheduling trigger
│   ├── patients.js                # Patient directory & clinical history modal
│   ├── doctors.js                 # Doctor directory & schedule inspection
│   ├── pharmacy.js                # Inventory tracking & safe stock deduction
│   ├── reports.js                 # Branch performance table & CSV export
│   └── notifications.js           # Slide-out notification drawer & read auditing
│
├── database/
│   ├── schema.sql                 # Complete 3NF normalized PostgreSQL schema
│   ├── seed.sql                   # Realistic multi-branch synthetic seed data
│   ├── rls_policies.sql           # Row Level Security branch isolation policies
│   ├── functions.sql              # Concurrency-safe booking & dispensing functions
│   ├── emergency_functions.sql    # Batch emergency cancellation & slot discovery
│   └── notification_functions.sql # Notification logger & unread counter
│
├── ml/
│   ├── train_model.py             # ML pipeline training LR & RF on Kaggle dataset
│   ├── predict.py                 # CLI & API inference engine
│   ├── requirements.txt           # Python ML dependencies
│   ├── README.md                  # Machine learning academic documentation
│   ├── data/                      # Dataset repository
│   └── models/                    # Trained model bundle & evaluation report
│
├── data_engineering/
│   ├── pipeline.py                # Multi-branch ETL pipeline
│   ├── generate_reports.py        # Executive report generator
│   └── output/                    # Generated analytical CSV and markdown marts
│
├── os_demo/
│   └── concurrent_booking.py      # Thread race condition & Mutex simulation
│
├── docs/
│   ├── ER_DIAGRAM.md              # Mermaid architectural ER diagram
│   ├── DATABASE_DESIGN.md         # Schema data dictionary & constraint strategy
│   ├── NORMALIZATION.md           # 1NF, 2NF, 3NF academic decomposition analysis
│   ├── PROJECT_REPORT.md          # Comprehensive academic project report
│   ├── TESTING.md                 # Quality verification matrix
│   ├── DEMO_SCRIPT.md             # Viva presentation walkthrough script
│   └── VIVA_QUESTIONS.md          # 10+ core viva questions with model answers
│
├── netlify.toml                   # Netlify SPA routing & security headers
├── .gitignore                     # Git ignore rules
└── README.md                      # Master project manual
```

---

## 🚀 Execution & Verification Guide

### 1. Run Machine Learning Training & Inference
```bash
# Train models (synthesizes Kaggle-conforming benchmark if offline)
python ml/train_model.py

# Run prediction for a 52-year-old patient booking 14 days in advance with SMS reminder
python ml/predict.py --age 52 --lead_days 14 --sms 1
```

### 2. Run Data Engineering Pipeline & Reports
```bash
python data_engineering/generate_reports.py
```
Outputs generated in `data_engineering/output/`:
- `fact_appointments.csv`
- `dim_branch_performance.csv`
- `executive_report.md`
- `executive_report.json`

### 3. Run Operating System Concurrency Demonstration
```bash
python os_demo/concurrent_booking.py
```
Demonstrates how unsynchronized threads cause double bookings, and how a Mutex lock guarantees mutual exclusion.

---

## 🗄️ Supabase PostgreSQL Setup Instructions

To connect to a live Supabase project:
1. Log in to [Supabase](https://supabase.com) and create a new project.
2. Open the **SQL Editor** in the Supabase dashboard.
3. Execute the SQL scripts in this exact order:
   - `database/schema.sql`
   - `database/seed.sql`
   - `database/rls_policies.sql`
   - `database/functions.sql`
   - `database/emergency_functions.sql`
   - `database/notification_functions.sql`
4. In Supabase Project Settings, copy your **Project URL** and **anon public key**.
5. Open `js/config.js` and paste them:
   ```javascript
   SUPABASE_URL: "https://your-project.supabase.co",
   SUPABASE_ANON_KEY: "your-anon-publishable-key"
   ```

*(Note: If Supabase credentials are not configured, MedTrack automatically runs in its built-in interactive demo mode with full multi-branch data.)*

---

## 🌐 Netlify Deployment Instructions

Target Live Site URL: **`https://luminous-starburst-5ce75d.netlify.app`**

### Option A: Manual Folder Drag-and-Drop (Instant)
1. Log in to [Netlify](https://app.netlify.com).
2. Go to **Sites** -> Select your site `luminous-starburst-5ce75d`.
3. Go to the **Deploys** tab.
4. Drag and drop the MedTrack project folder directly onto the upload zone.
5. Netlify will deploy all static pages and application routes instantly based on `netlify.toml`.

### Option B: GitHub-Connected Continuous Deployment
1. Initialize a git repository and commit all project files:
   ```bash
   git init
   git add .
   git commit -m "MedTrack Final Master Release"
   ```
2. Push to your GitHub repository.
3. Link the repository to your Netlify site. The `netlify.toml` file automatically configures the publish directory as `.` and applies all SPA routing rules.

---

## 🎓 Academic Viva Highlights

When presenting to examiners:
1. **Homepage:** Show that `index.html` loads directly without forcing a login screen.
2. **Role Switcher:** Use the topbar dropdown to switch between **Super Admin**, **Branch Head A**, **Doctor**, **Receptionist**, and **Patient**.
3. **Emergency Auto-Reschedule:** In `emergency.html`, click **Report Hospital Emergency**, select Branch A and Dr. Sharma, and confirm. Show that affected appointments are cancelled, replacement slots are automatically created, and the patient receives an urgent In-App reschedule notification in the top bell drawer.
4. **Concurrency:** Point to `os_demo/concurrent_booking.py` and explain how `idx_unique_active_doctor_slot` solves race conditions at the database level.
